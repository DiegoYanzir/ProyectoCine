/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Consultas;
import Modelo.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author exito soacha
 */
@WebServlet(name = "regisControl", urlPatterns = {"/regisControl"})
public class regisControl extends HttpServlet {

    Consultas con = new Consultas();
    Usuario usa = new Usuario();
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {}

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("registrar");
        PrintWriter out = response.getWriter();
        
        if(accion.equals("Registrarse")){
            String usuario = request.getParameter("usuario");
            String nombre = request.getParameter("nombre");
            String cedula = request.getParameter("cedula");
            String contra1 = request.getParameter("contra1");
            String contra2 = request.getParameter("contra2");
            String email = request.getParameter("email");
            String telefono = request.getParameter("telefono");
            
            if(usuario.equals("") || nombre.equals("") || cedula.equals("") || contra1.equals("") || contra2.equals("") || email.equals("") || telefono.equals("")){
                out.print("Campos vacio");
                RequestDispatcher rd=request.getRequestDispatcher("registro.jsp");  
            rd.include(request, response);
            }else{
                if(contra1.equals(contra2)){
                    usa.setUsuario(usuario);
                    usa.setNombre(nombre);
                    usa.setCedula(cedula);
                    usa.setContraseña(contra2);
                    usa.setEmail(email);
                    usa.setTelefono(telefono);
                    if(con.RegistroUsuario(usa)==true){
                        
                        RequestDispatcher rd=request.getRequestDispatcher("menu.jsp");  
                        rd.include(request, response);
                        out.print("Todo correcto");
                    }else{
                        
                        RequestDispatcher rd=request.getRequestDispatcher("registro.jsp");  
                        rd.include(request, response);
                        out.print(con.error());
                    }
                
                }else{
                    out.print("Contraseñas diferentes");
                    RequestDispatcher rd=request.getRequestDispatcher("registro.jsp");  
                    rd.include(request, response);
                }
                        
            }
            
            
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}