
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;

public class Consultas extends Conexion {
    
    Connection con;
    PreparedStatement ps;
    ResultSet res;
    int r;
    
    public List mostrarLista(){
        List<Usuario> lista = new ArrayList<>();
                try{
                    con = conexion();
                    ps = con.prepareStatement("select * from USUARIO");
                    res = ps.executeQuery();
                    
                    while(res.next()){
                        Usuario us = new Usuario();
                        us.setUsuario(res.getString(1));
                        us.setNombre(res.getString(2));
                        us.setCedula(res.getString(3));
                        us.setContraseña(res.getString(4));
                        us.setEmail(res.getString(5));
                        us.setTelefono(res.getString(6));
                        lista.add(us);
                    }
                    
                    
                }catch(Exception ex){
                    
                }
        return lista;        
    }
    String error;
    public boolean iniciarSesion(Usuario us){
        boolean estado = false;
        
        try{
            con = conexion();
            ps = con.prepareStatement("SELECT * FROM USUARIO WHERE USUARIO = ?");
            ps.setString(1,us.getUsuario());
            res = ps.executeQuery();
            
            if(res.next()){
                if(us.getContraseña().equals(res.getString(4))){
                    
                    us.setUsuario(res.getString(1));
                    us.setNombre(res.getString(2));
                    us.setCedula(res.getString(3));
                    us.setEmail(res.getString(5));
                    us.setTelefono(res.getString(6));
                    estado = true;
                }else{
                    estado = false;
                    error = "Contraseña erronea";
                }
            }else{
                estado = false;
                error = "Usuario no existente";
            }
            
        }catch(SQLException sex){    
            estado = false;
            error = sex.getMessage();
        }catch(Exception ex){
            estado = false;
            error = ex.getMessage();
        }
      
        return estado;
    }
    
    public String error(){
        return error;
    }
    
    public boolean RegistroUsuario(Usuario usu){
        boolean resultado = false;
        try{
            con = conexion();
            ps = con.prepareStatement("INSERT INTO USUARIO(USUARIO,NOMBRE,CEDULA,CONTRASEÑA,EMAIL,TELEFONO)VALUES(?,?,?,?,?,?)");
            ps.setString(1,usu.getUsuario());
            ps.setString(2,usu.getNombre());
            ps.setString(3,usu.getCedula());
            ps.setString(4,usu.getContraseña());
            ps.setString(5,usu.getEmail());
            ps.setString(6,usu.getTelefono());
            
            ps.execute();
            
            resultado = true;
        }catch(SQLException sex){
            resultado = false;
            error = Integer.toString(sex.getErrorCode());
            error += "  " + sex.getMessage();
        }catch(Exception ex){
            resultado = false;
            error = ex.getMessage();
        }
        
        return resultado;
    }
    
}
