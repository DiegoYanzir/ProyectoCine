
package Modelo;


public class Usuario {

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    private String usuario,nombre,cedula,contraseña,email,telefono;
    
    public Usuario(){
        usuario = null;
        nombre = null;
        cedula = null;
        contraseña = null;
        email = null; 
        telefono = null;
    }
    
    public void guardar(String usuario,String nombre,String cedula,String contraseña,String email,String telefono){
        this.usuario = usuario;
        this.nombre = nombre;
        this.cedula = cedula;
        this.contraseña = contraseña;
        this.email = email; 
        this.telefono = telefono;
    }
    
}
